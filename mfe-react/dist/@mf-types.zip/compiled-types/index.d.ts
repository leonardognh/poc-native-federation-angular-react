import "./index.css";
declare const mount: (el: HTMLElement) => () => void;
export { mount };
export default mount;
